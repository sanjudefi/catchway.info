<!doctype html>
<html lang="en">




<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>Privacy Policy</h1>
                    <!-- <p>Tron token development is your best choice if you want all the functionalities of Ethereum, without the outrageous gas fees.</p> -->
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                </div>
            </div> 
        </div>    
    </div>
</section>
<br><br>

<section id="benefit-04">

    <br><br><br>
    <div class="container">       
        <div class="row">   
            <div class="col-md-12">
                <div class="address_wrapper">
                    <div class="contact-info-wrapper">
                        <div class="contact-info">
                            
            <div class="row contact-details">
                <style>
                    .list-style li {
                        list-style: circle;
                        margin-left: 50px;
                    }
                    .list-style li ul li {
                        list-style: circle;
                        margin-left: 50px;
                    }
                </style>
				<div class="col-sm-12">
					<ul class="list-style">
                        <li>The website,www.catchway.com and any personal information collected from users of this site is solely owned by Catchway Web Solutions Pvt Ltd further referred as  “we”, “us”, “our”, or “the company”.</li>
                        <li>This Privacy Policy applies only to this website, and is not applicable to the  collection and use of personal information by any third party via any website to which there are links on this Site.To enhance our website we are linked to a few authentic third-party services and the privacy policy of which may be different from us and we assume no responsibility for their agreement.</li>
                        <li>By accessing the website , using the website,interacting with our website, subscribing to any of our blogs, requesting information, or using chat support,  you or the users consent to our privacy policy including  collecting and using personal information about you in accordance with this Privacy Policy.</li>
                        <li>We may ask, store, and process any/all of these data mentioned after getting your permission, when you request any of our services:
                            <ul>
                                <li>Your Name</li>
                                <li>Your Contact Number</li>
                                <li>Your Email Id</li>
                                <li>Other information that you choose to share</li>
                            </ul>
                        </li>
                        <li>We never share your personal data with any third party in any circumstance</li>
                        <li>Our privacy policy assures you that any details filled or data entered in the form or chat will not be misused, sold, and/or rented. However, the data may be used for future communication and internal record keeping purposes.</li>
                        <li>We maintain a significant level of control over how your personal information is handled, used and stored. Our privacy policy reassures a trustworthy and secure association in every way possible.</li>
                        <li>Catchway.com may use cookies to track visitor statistics and you are at your discretion to disable cookies by changing the settings in your computer.</li>
                        <li>If you have any question regarding our privacy policy, please reach us at info@catchway.com</li>
                    </ul>
                </div>
			
            </div>
                        </div>
                    </div>    
                </div>
            </div>               
        </div>           
    </div>
    <div id="particles11-js" class="particles"><canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="1440" height="789"></canvas></div>
</section>

<br><br><br>

<?php include('footer.php'); ?>

</body>

</html>
