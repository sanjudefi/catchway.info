

    <!-- jquery -->
    <script src="services/js/jquery-3.6.0.min.js"></script>
    <!-- bootstrap five js -->
    <script src="services/js/bootstrap.bundle.min.js"></script>
    <!-- nice select js -->
    <script src="services/js/jquery.nice-select.min.js"></script>
    <!-- magnific popup js -->
    <script src="services/js/jquery.magnific-popup.min.js"></script>
    <!-- counter js -->
    <script src="services/js/counter.js"></script>
    <!-- waypoint js -->
    <script src="services/js/waypoint.min.js"></script>
    <!-- wow js -->
    <script src="services/js/wow.min.js"></script>

    <!-- ==== js dependencies end ==== -->

    <!-- plugin js -->
    <script src="services/js/plugin.js"></script>
    <!-- main js -->
    <script src="services/js/main.js"></script>


    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
    var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
    (function(){
    var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
    s1.async=true;
    s1.src='https://embed.tawk.to/609395f9b1d5182476b62597/1f5083mfl';
    s1.charset='UTF-8';
    s1.setAttribute('crossorigin','*');
    s0.parentNode.insertBefore(s1,s0);
    })();
    </script>
    <!--End of Tawk.to Script-->


    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MKH65HK"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->