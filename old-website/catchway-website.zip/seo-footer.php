

    
    
    
  <style>
      .dark-bg .card {
        background: transparent;
        border: 0;
      }
  </style>
  
  
    <!-- ==== footer section start ==== -->
    <footer class="footer section__space__bottom">
        <div class="container">
            <div class="footer-area">
                <div class="">
                    <div class="footer__credit">
                        <div class="row d-flex align-items-center">
                            <div class="col-lg-12 text-center">
                                <div class="footer__credit__left text-center">
                                    <p class="text-center text-lg-center">
                                        Copyright © 2025. All Rights Reserved By <a href="https://catchway.com/">Catchway</a>
                                        <!--br><a href="tel:+16197149179">+16197149179</a> &emsp; <a href="tel:+971585048744">+971585048744</a-->
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ==== #footer section end ==== -->

    <!-- Scroll To Top -->
    <a href="javascript:void(0)" class="scrollToTop">
        <i class="fa-solid fa-angles-up"></i>
    </a>

    <!--a href="https://api.whatsapp.com/send?phone=358417945831" target="_blank" class="foot-whatsapp"><img src="services/images/icon_whatsapp-1.png" /></a>
    <a href="tel:358417945831" class="foot-call"><img src="services/images/icon_call-1.png" /></a-->
    
    