<!doctype html>
<html lang="en">




<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>ICO Coin Development</h1>
                    <p>At Catchway, we provide highly secure and reliable ICO Solutions to strengthen fundraising prospects and potential. From conceptualizing the token to setting up the dashboard to the final leg of marketing, we provide end to end services.</p>
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                    
                </div>
            </div> 
        </div>    
    </div>
</section>



<section id="" >
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-sm-12 col-md-6 col-lg-6 benefits-single-item">
                <table class="table table-striped">
                    <tr>
                        <th>Pre ICO</th>
                        <th>Post ICO</th>
                    </tr>
                    <tr>
                        <td>White Paper</td>
                        <td>Exchange Listing Assistance</td>
                    </tr>
                    <tr>
                        <td>Light Paper</td>
                        <td>Blockchain Software Development</td>
                    </tr>
                    <tr>
                        <td>Landing Page</td>
                        <td>Price Services </td>
                    </tr>
                    <tr>
                        <td>Technology Set Up</td>
                        <td>ICO Summary</td>
                    </tr>
                    <tr>
                        <td>Block Explorer Add On</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td>Smart Contract set up</td>
                        <td></td>
                    </tr>
                </table>
            </div>
            
        </div>    
    </div>
</section>

<?php include('footer.php'); ?>
</body>

</html>
