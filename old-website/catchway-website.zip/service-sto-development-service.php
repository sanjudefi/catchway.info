<!doctype html>
<html lang="en">




<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>STO Development Services</h1>
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                </div>
            </div> 
        </div>    
    </div>
</section>



<section id="" >
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-12 col-lg-12 benefits-single-item text-center">
                <h2>We offer a range of STO Services </h2><br><br>
            </div>
            <div class="col-sm-12 col-md-5 col-lg-7">
                <div class="about-img">
                    <div class="img-wrapper wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s">
                         <img src="images/prototype.png" width="100%" alt="">
                    </div>
                </div>
            </div>          

            <div class="col-sm-12 col-md-7 col-lg-5 benefits-single-item">
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> STO Token Development  (Equity, Asset, Debt)</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> STO Exchange Platform</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> STO Marketing</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Blockchain based Product Development </p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Tokenized Asset Offering Development</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Equity Token Offering Development</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> White Paper Development</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Payment system development </p>
            </div>
            
        </div>    
    </div>
</section>

<br><br><br>

<section id="" >
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-12 col-lg-12 benefits-single-item text-center">
                <h2>Features of STO Solutions</h2><br><br>
            </div>
            <div class="col-sm-12 col-md-5 col-lg-7">
                <div class="about-img">
                    <div class="img-wrapper wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s">
                         <img src="images/prototype.png" width="100%" alt=""  style="background: #ffffff10; padding: 40px;">
                    </div>
                </div>
            </div>          

            <div class="col-sm-12 col-md-7 col-lg-5 benefits-single-item" style="background: #00000010; padding: 40px;">
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Secure Wallet </p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Global Capital Investment </p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Greater Market Efficiency </p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> No intermediaries</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Customized Blockchain</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Automated SEC compliant</p>
            </div>
            
        </div>    
    </div>
</section>

<?php include('footer.php'); ?>
</body>

</html>
