<!doctype html>
<html lang="en">




<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>BEP 20 Token Development</h1>
                    <p>A BEP20 token generator can give you a token quickly but will lack codebase quality if you’re a serious project. To  enter the DeFi market, our smart contract specialists can  develop bep20 tokens that pass audits and work efficiently.</p>
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                </div>
            </div> 
        </div>    
    </div>
</section>



<section id="" >
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-12 col-lg-12 benefits-single-item text-center">
                <h2>The Services Include </h2><br><br>
            </div>
            <div class="col-sm-12 col-md-5 col-lg-5">
                <div class="about-img">
                    <div class="img-wrapper wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s">
                         <img src="images/bep-20-token-development.webp" width="100%" alt="" style="background: #ffffff10; padding: 40px;">
                    </div>
                </div>
            </div>          

            <div class="col-sm-12 col-md-7 col-lg-7 benefits-single-item" style="background: #00000010; padding: 40px;">
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Token Creation </p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Smart Contract Integration</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> NFT Marketplace</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> DEX Development  </p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Wallet Integration</p>
                <p class=" wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s"><i class="fa fa-leaf"></i> Token Listing </p>
            </div>
            
        </div>    
    </div>
</section>



<section id="benefit-04">
    <div class="container">
        <div class="row">        
            <div class="col-sm-12">
                <div class="sub-title">
                    <h2 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: fadeInUp;">Contract Features</h2>
                </div>
            </div>
        </div>      
        <div class="row">        
            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="single-items wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: fadeInUp;">
                    <div class="benefits-icon">
                        <img src="images/icons/benefits4-1.png" alt="">
                    </div>
                    <div class="benefits-content">
                        <h3>Token Burn</h3>
                        <p>This feature allows you to destroy tokens and take them out of circulation. This in turn makes your token scarcer and more valuable.</p>    
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="single-items wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.3s; animation-name: fadeInUp;">
                    <div class="benefits-icon">
                        <img src="images/icons/benefits4-2.png" alt="">
                    </div>
                    <div class="benefits-content">
                        <h3>Token Pause</h3>
                        <p>The token pause feature allows you to pause all transactions on a token. Perfect for minimizing damage in case of an issue.</p>    
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="single-items wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.4s; animation-name: fadeInUp;">
                    <div class="benefits-icon">
                        <img src="images/icons/benefits4-3.svg" alt="">
                    </div>
                    <div class="benefits-content">
                        <h3>Token Mint</h3>
                        <p>The token mint feature allows you to create new tokens and bring them into circulation. Perfect for reward-based utility tokens.</p>    
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="single-items wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: fadeInUp;">
                    <div class="benefits-icon">
                        <img src="images/icons/benefits4-4.webp" alt="">
                    </div>
                    <div class="benefits-content">
                        <h3>Pause Address</h3>
                        <p>With this feature, you can pause individual addresses. It helps you take control of your project and screen-put bat actors in the network.</p>    
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="single-items wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.3s; animation-name: fadeInUp;">
                    <div class="benefits-icon">
                        <img src="images/icons/benefits4-5.png" alt="">
                    </div>
                    <div class="benefits-content">
                        <h3>Redistribution (Reflection)</h3>
                        <p>This feature allows you to distribute rewards to your token holders based on the number of tokens they hold I'm their wallets.</p>    
                    </div>
                </div>
            </div>

            <div class="col-sm-12 col-md-6 col-lg-6">
                <div class="single-items wow fadeInUp" data-wow-duration="2s" data-wow-delay=".4s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.4s; animation-name: fadeInUp;">
                    <div class="benefits-icon">
                        <img src="images/icons/benefits4-6.webp" alt="">
                    </div>
                    <div class="benefits-content">
                        <h3>Auto LP additions</h3>
                        <p>You can take an amount from each token transaction and add to the liquidity pool. This makes your liquidity pool larger gradually.</p>    
                    </div>
                </div>
            </div>

        </div>  
    </div>
</section>

<br><br><br>

<?php include('footer.php'); ?>
</body>

</html>
