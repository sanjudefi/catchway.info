<!doctype html>
<html lang="en">




<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>Terms and Conditions</h1>
                    <!-- <p>Tron token development is your best choice if you want all the functionalities of Ethereum, without the outrageous gas fees.</p> -->
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                </div>
            </div> 
        </div>    
    </div>
</section>
<br><br>

<section id="benefit-04">

    <br><br><br>
    <div class="container">       
        <div class="row">   
            <div class="col-md-12">
                <div class="address_wrapper">
                    <div class="contact-info-wrapper">
                        <div class="contact-info">
                            
            <div class="row contact-details">
                <style>
                    .list-style li {
                        list-style: circle;
                        margin-left: 50px;
                    }
                    .list-style li ul li {
                        list-style: circle;
                        margin-left: 50px;
                    }
                </style>
				<div class="col-sm-12">
                    <p>Catchway strongly recommends that our clients/ users/ visitors reads through the rules and regulations to ensure a clear understanding  while enquiring for or signing up for for Blockchain projects.</p>
					<ul class="list-style">
                        <li>We employ the use of cookies which facilitate the retrieval of  the user’s details for each visit and enable the functionality of certain areas to make it easier for people visiting our website. By accessing our website , you hereby consent to use cookies in agreement with our privacy policy. </li>
                        <li>Catchway Web Solutions Pvt Ltd  owns the intellectual property rights for all material on catchway.com website and all intellectual property rights are reserved. </li>
                        <li>You are restrained from

                            <ul>
                                <li>Republishing any  material partly or fully from catchway.com</li>
                                <li>Sell, rent or sub-license material from catchway.com</li>
                                <li>Copy, reproduce, redistribute or duplicate materials or content from catchway.com in full or part</li>
                            </ul>
                        </li>
                        <li>The following organizations may link to our Website without prior written consent or approvals depending on the jurisdictions of our operations 

                            <ul>
                                <li>Government agencies.</li>
                                <li>Search engines.</li>
                                <li>News organizations.</li>
                                <li>Online directory distributors</li>
                            </ul>
                        </li>
                        <li>No use of Catchwaylogo or other artwork will be allowed for linking without a trademark license agreement</li>
                        <li>Use of the Services provided by the Company shall be conditional on having access to the World Wide Web, either directly or indirectly. Payment of any fees associated with the said access shall be the responsibility of the User, who shall also be responsible for providing all the necessary equipment to connect to the World Wide Web, whatever form the said equipment may take.</li>
                        <li>You may not create a link to any page of this website without our prior written consent.</li>
                    </ul>
                </div>
			
            </div>
                        </div>
                    </div>    
                </div>
            </div>               
        </div>           
    </div>
    <div id="particles11-js" class="particles"><canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="1440" height="789"></canvas></div>
</section>

<br><br><br>

<?php include('footer.php'); ?>
</body>

</html>
