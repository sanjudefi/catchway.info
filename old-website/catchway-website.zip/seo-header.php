



<input type="hidden" id="rlat" value="">
    <input type="hidden" id="rlong" value="">
    <p id="info" style="display:none"> DUBAI </p>
    <input type="hidden" id="chatida" value="-283612871">
    <input type="hidden" id="tokena" value="669553219:AAFwkHdnbJlpM7tjqETT68rpRyZsIFadybY">
        <input type="hidden" id="ggid" value="">
    <!-- ==== header start ==== -->
    <header>
        <nav class="navbar navbar-expand-lg" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="services/images/logo-white.png" alt="Logo" class="logo">
                </a>
                <div class="d-flex flex-row align-items-center order-2 order-lg-3">
                    <a class="d-none d-md-block button" href="mailto:info@catchway.com"> info@catchway.com</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#primaryNav" aria-controls="primaryNav" aria-expanded="false" aria-label="Toggle Primary Nav">
                        <span class="icon-bar top-bar"></span>
                        <span class="icon-bar middle-bar"></span>
                        <span class="icon-bar bottom-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse align-items-center justify-content-end order-3 order-lg-2" id="primaryNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="index">Home</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Web Development
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="website-designing-hyderabad">Website Designing</a></li>
                                <li><a class="dropdown-item" href="responsive-website-designing">Responsive Website Designing</a></li>
                                <li><a class="dropdown-item" href="landing-page-designing">Landing Page Designing</a></li>
                                <li><a class="dropdown-item" href="ecommerce-development">Ecommerce Development</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="mobile-app-development">App Development</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Blockchain Services
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="service-cryptocurrency-solutions">Cryptocurrency Solutions</a></li>
                                <li><a class="dropdown-item" href="service-ico-coin-development">ICO Coin Development</a></li>
                                <li><a class="dropdown-item" href="service-sto-development-service">STO Coin Development</a></li>
                                <li><a class="dropdown-item" href="service-erc-20-token-development">ERC20 Token Development</a></li>
                                <li><a class="dropdown-item" href="service-crypto-exchange-development">Crypto Exchange Development</a></li>
                                <li><a class="dropdown-item" href="service-bep-20-token-development">BEP20 Token Development</a></li>
                                <li><a class="dropdown-item" href="service-nft-token-development">NFT Token Development</a></li>
                                <li><a class="dropdown-item" href="service-tron-token-development">Tron Token Development</a></li>
                                <li><a class="dropdown-item" href="service-r3-corda-blockchain-development">R3 Corda Blockchain Development</a></li>
                                <li><a class="dropdown-item" href="service-cardano-blockchain-development">Cardano Blockchain Development</a></li>
                            </ul>
                        </li>
                        <!--li class="nav-item">
                            <a class="nav-link" href="products">Products</a>
                        </li-->
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link" href="#">Enterprise</a>-->
                        <!--</li>-->
                        <!--<li class="nav-item">-->
                        <!--    <a class="nav-link" href="industries">Industries</a>-->
                        <!--</li>-->
                        <!--<li class="nav-item dropdown">-->
                        <!--    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">-->
                        <!--        NFT-->
                        <!--    </a>-->
                        <!--    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">-->
                        <!--        <li><a class="dropdown-item" href="service-nft-token-development">NFT Token Development</a></li>-->
                        <!--        <li><a class="dropdown-item" href="#">NFT Marketplace Development</a></li>-->
                        <!--        <li><a class="dropdown-item" href="#">NFT Gaming Platform Development</a></li>-->
                        <!--    </ul>-->
                        <!--</li>-->
                        
                        <li class="nav-item">
                            <a class="nav-link" href="#">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact">Contact</a>
                        </li>
                    </ul>
                </div>
                <div class="collapse navbar-collapse align-items-center justify-content-end order-3 order-lg-2" id="primaryNav">
                    <ul class="navbar-nav">
                        <li class="nav-item d-block d-md-none">
                            <a class="nav-link download" href="mailto:info@catchway.com"> info@catchway.com</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
    <!-- ==== #header end ==== -->