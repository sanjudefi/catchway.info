<ul class="banner-social">
    <li><a href="https://telegram.me/Janz_dxb" target="_blank"><i class="fab fa-telegram"></i></a></li>
    <li><a href="https://www.facebook.com/catchway.io" target="_blank"><i class="fab fa-facebook"></i></a></li>
    <!--<li><a href="" target="_blank"><i class="fab fa-twitter"></i></a></li>-->
    <li><a href="https://www.instagram.com/catchway.io/" target="_blank"><i class="fab fa-instagram"></i></a></li>
    <li><a href="https://www.linkedin.com/company/catchway-web-solutions-pvt-ltd/" target="_blank"><i class="fab fa-linkedin"></i></a></li>
    <!--li><a href="https://api.whatsapp.com/send?phone=971585048744" target="_blank"><i class="fab fa-whatsapp"></i></a></li-->
</ul>