<!doctype html>
<html lang="en">




<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>R3 Corda Blockchain Development</h1>
                    <p>Your businesses need a blockchain solution compatible to handle confidential information and the fast-paced environment. R3 Corda is a Distributed Ledger Technology solution (DLT) that emphasizes privacy, scalability, and security making it the perfect solution for building apps if you are an enterprise.</p>
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                </div>
            </div> 
        </div>    
    </div>
</section>



<section id="" >
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-12 col-md-12 col-lg-12 benefits-single-item text-center">
                <h2>Our Services </h2><br><br>
            </div>
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon1.png" width="60">
                    <p>Corda Blockchain Consulting</p>
                </div>
            </div> 
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon2.webp" width="60">
                    <p>CordApp Development</p>
                </div>
            </div> 
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon3.png" width="60">
                    <p>Smart Contracts</p>
                </div>
            </div> 
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon4.png" width="60">
                    <p>Token Creation</p>
                </div>
            </div> 
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon5.png" width="60">
                    <p>Private Blockchain Development</p>
                </div>
            </div> 
            
        </div>    
    </div>
</section>
<br><br>



<section id="benefit-04">
    <div class="container">
        <div class="row">        
            <div class="col-sm-12">
                <div class="sub-title">
                    <h2 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: fadeInUp;">R3 Corda Blockchain Features</h2>
                </div>
            </div>
        </div>      
        <div class="row justify-content-center">        
            
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon6.png" width="60">
                    <p>Smart Contract Solutions</p>
                </div>
            </div>       
            
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon7.png" width="60">
                    <p>High Scalability</p>
                </div>
            </div>       
            
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon8.png" width="60">
                    <p>Multilateral Ledger</p>
                </div>
            </div>       
            
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon9.png" width="60">
                    <p>Enterprise Support</p>
                </div>
            </div>     
            
            <div class="col-sm-6 col-md-4 col-lg-4 text-center">
                <div class="icon-box">
                    <img src="images/icons/rc-icon10.png" width="60">
                    <p>Point to Point Architecture</p>
                </div>
            </div>  

        </div>  
    </div>
</section>

<br><br><br>

<?php include('footer.php'); ?>
</body>

</html>
