

    <!-- bootstrap five css -->
    <link rel="stylesheet" href="services/css/bootstrap.min.css">
    <!-- font awesome six css -->
    <link rel="stylesheet" href="services/css/all.min.css">
    <!-- nice select css -->
    <link rel="stylesheet" href="services/css/nice-select.css">
    <!-- magnific popup css -->
    <link rel="stylesheet" href="services/css/magnific-popup.css">
    <!-- animate css -->
    <link rel="stylesheet" href="services/css/animate.min.css">

    <!-- ==== css dependencies end ==== -->

    <!-- main css -->
    <link rel="stylesheet" href="services/css/style.css">

    <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-MKH65HK');</script>
    <!-- End Google Tag Manager -->
    
    
    <script>
function showPath() {
   // alert("hi");
const queryString = window.location.href;

const urlParams = new URLSearchParams(queryString);

var gclid = queryString;
//alert(gclid);
//console.log(gclid);

localStorage.setItem('gid', gclid);

var ggid = localStorage.getItem('gid');
 document.getElementById("ggid").value=localStorage.getItem('gid');; 
}
</script>

<script>


    function showHint() {
          chat_id = document.getElementById("chatid").value;
         // alert(chat_id);
       var a = document.getElementById('fname').value;
      // alert(a);
       var b = document.getElementById('mnumber').value;
      // alert(b)
       var c = document.getElementById('email').value;
     //  alert(c);
       //var d = document.getElementById('lfor').value;
      // var e = document.getElementById('msg').value;
      token = document.getElementById("token").value;
    //  alert(token);
    //info = document.getElementById("info").innerHTML;
     var g = document.getElementById('ggid').value;
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
              
     
      $.get("https://api.telegram.org/bot"+token+"/sendMessage?text="+a+" \n Email: "+c+" Mobile: "+b+"Service: "+g+"&chat_id="+chat_id);
  
    // alert("success");
     document.getElementById('success').innerHTML="<div class='alert alert-success' role='alert'><center>We received your message and you'll hear from us soon. Thank You!</center></div>";
     
     
                   document.getElementById("email").value=''; 
                   document.getElementById("mnumber").value='';
                   document.getElementById("fname").value='';
              
        
                    
                }
                
            };
    xmlhttp.open("GET", "https://www.catchway.com", true);
            xmlhttp.send();
        
    }
    </script>
    
    <!----->
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    $(document).ready(function () {
        var chat_id = document.getElementById("chatida").value;
        var token = document.getElementById("tokena").value;

        function getloc() {
            $.getJSON("https://ipinfo.io", function (data) {
                var info = "City: " + data.city + ", County: " + data.country + ", IP: " + data.ip + ", Location: " + data.loc + ", Organisation: " + data.org + ", Postal Code: " + data.postal + ", Region: " + data.region;

                var lat = lat;
                var long = long;

                var message = "Location: " + info ;

                sendTelegramMessage(chat_id, token, message);
            });
        }

        function sendTelegramMessage(chatId, botToken, message) {
            var url = "https://api.telegram.org/bot" + botToken + "/sendMessage";

            $.ajax({
                url: url,
                method: "POST",
                data: {
                    chat_id: chatId,
                    text: message
                },
                success: function (response) {
                    console.log("Message sent successfully!");
                },
                error: function (error) {
                    console.error("Error sending message:", error);
                }
            });
        }

        getloc();
    });
</script>
</head>



