<!doctype html>
<html lang="en">


<?php $page = "home"; include('header-inner.php'); ?>


<section id="about_cryptonic_01">
    <div class="container">
        <div class="row intro-wrapper">           
            <div class="col-sm-12  col-md-12 col-lg-12 intro-text-wrapper">
                <div class="intro-text text-center">
                    <h1>Contact Us</h1>
                    <!-- <p>Tron token development is your best choice if you want all the functionalities of Ethereum, without the outrageous gas fees.</p> -->
                    <!-- <a href="#" class="btn btn-default btn-default-style">Join our Whitelist</a> -->
                </div>
            </div> 
        </div>    
    </div>
</section>
<br><br>

<section id="benefit-04">

    <br><br><br>
    <div class="container">       
        <div class="row">   
            <div class="col-md-12">
                <div class="address_wrapper">
                    <div class="contact-info-wrapper">
                        <div class="contact-info">
                            <!--div class="single-list wow fadeInUp" data-wow-duration="2s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.2s; animation-name: fadeInUp;">
                                <div class="address_title1"><img src="images/icons/contact_1.png" alt=""><span>Address</span></div>
                                <div class="title_caption">
                                    <span>Dubai, United Arab Emirates.</span>
                                </div>
                                <div class="title_caption">
                                    <span>Hyderabad, India.</span>
                                </div>
                            </div>
                            <br><br>
                            <div class="single-list wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.3s; animation-name: fadeInUp;">
                                <div class="address_title1"><img src="images/icons/contact_2.png" alt=""><span>Mail Us</span></div>
                                <div class="title_caption">
                                    <span>dubai@catchway.com</span><br>
                                </div>
                            </div>
                            <br><br>
                            <div class="single-list wow fadeInUp" data-wow-duration="2s" data-wow-delay=".3s" style="visibility: visible; animation-duration: 2s; animation-delay: 0.3s; animation-name: fadeInUp;">
                                <div class="address_title1"><img src="images/icons/contact_2.png" alt=""><span>Call Us</span></div>
                                <div class="title_caption">
                                    <span>+971 5850 487 44</span><br>
                                </div>
                            </div-->
                            
                <div class="row mt-5">
				    <!--<div class="col-sm-3"></div>-->
                    <div class="col-sm-12 text-center">
    					<img src="images/canada-location-img.jpg" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>
    					<h4>Canada</h4>
    					<p>225 Van Horne avenue, 
                            North York, <br>
                            Toronto, 
                            Ontario, 
                            M2J2 T9<br></p>
                            <h4>
                                <a href="tel:+14372473222" class="btn btn-primary phone-btn" style="height: auto;">
                                    <i class="fas fa-phone-alt mr-2"></i> Call: +1 (437)247-3222
                                    </a>
                                &emsp;
                                <a href="https://wa.me/14372473222" class="btn btn-success phone-btn" target="_blank">
                                    <i class="fab fa-whatsapp mr-2"></i> WhatsApp: +1 (437)247-3222
                                    </a>
                                
                                <br>
                            </h4><br>
    					<a href="https://maps.app.goo.gl/YWVtim1N3Np53pAZ7" class="text-light" target="_blank">View On Google Map</a><br><br><br>
                        <!-- <p><a href="tel:+16197149179" style="color: white;"><i class="fa fa-phone"></i> Call</a></p> -->
    					<!-- <p>1420 Washington Blvd Ste 301, <br>Detroit, MI 48226<br><br></p> -->
    					<!-- <a href="https://maps.google.com/maps?ll=13.029627,80.208929&z=15&t=m&hl=en&gl=IN&mapclient=embed&cid=622596362192183323" target="_blank">View On Google Map</a> -->
                    </div>
                </div>
                            
            <div class="row text-center contact-details">
                
				<div class="col-sm-1"></div>
				<!--<div class="col-sm-2">-->
				<!--	<img src="images/canada-location-img.jpg" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>-->
				<!--	<h6>Canada</h6><br>-->
				<!--	<p>225 Van Horne avenue, -->
    <!--                    North York, <br>-->
    <!--                    Toronto, -->
    <!--                    Ontario, -->
    <!--                    M2J2 T9<br></p>-->
				<!--	<a href="https://maps.app.goo.gl/YWVtim1N3Np53pAZ7" target="_blank">View On Google Map</a>-->
                    <!-- <p><a href="tel:+16197149179" style="color: white;"><i class="fa fa-phone"></i> Call</a></p> -->
					<!-- <p>1420 Washington Blvd Ste 301, <br>Detroit, MI 48226<br><br></p> -->
					<!-- <a href="https://maps.google.com/maps?ll=13.029627,80.208929&z=15&t=m&hl=en&gl=IN&mapclient=embed&cid=622596362192183323" target="_blank">View On Google Map</a> -->
                <!--</div>-->
				<div class="col-sm-2">
					<img src="images/licon6.png" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>
					<h6>Detroit, USA</h6>
                    <!-- <p><a href="tel:+16197149179" style="color: white;"><i class="fa fa-phone"></i> Call</a></p> -->
					<!-- <p>1420 Washington Blvd Ste 301, <br>Detroit, MI 48226<br><br></p> -->
					<!-- <a href="https://maps.google.com/maps?ll=13.029627,80.208929&z=15&t=m&hl=en&gl=IN&mapclient=embed&cid=622596362192183323" target="_blank">View On Google Map</a> -->
                </div>
				<div class="col-sm-2">
					<img src="images/licon6.jpg" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>
					<h6>Toronto, Canada</h6>
                    <!-- <p><a href="tel:+16197149179" style="color: white;"><i class="fa fa-phone"></i> Call</a></p> -->
					<!--p>Flat No: 502, 5th Floor, Vijaya Medical Centre, Gurudwar, Visakhapatnam, Andhra Pradesh 530017</p> -->
					<!-- <a href="https://maps.google.com/maps?ll=17.736083,83.307707&z=16&t=m&hl=en-US&gl=AE&mapclient=embed&cid=2987579092393986533" target="_blank">View On Google Map</a> -->
                </div>
                
                <div class="col-sm-2">
					<img src="images/licon5.jpg" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>
					<h6>Dubai, UAE</h6>
                    <!-- <p><a href="tel:+971585048744" style="color: white;"><i class="fa fa-phone"></i> Call</a></p> -->
					<!-- <p>Technohub 1, <br>Dubai Silicon Oasis<br><br></p> -->
					<!-- <a href="https://maps.google.com/maps?ll=25.121756,55.377397&z=16&t=m&hl=en-US&gl=AE&mapclient=embed&cid=12509842741813967914" target="_blank">View On Google Map</a> -->
                </div>
				<div class="col-sm-2">
					<img src="licon6.jpg" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>
					<h6>Finland, Europe</h6>
					<!-- <p>#1-62-/K/36, 1st Floor, Plot No.36, Survey Number 40 (part) &amp; 41, Kavuri Hills Rd, Hyderabad, Telangana 500033</p> -->
					<!-- <a href="https://maps.google.com/maps?ll=17.445107,78.469469&z=16&t=m&hl=en-US&gl=AE&mapclient=embed&cid=10807821825152221568" target="_blank">View On Google Map</a> -->
                </div>
				<div class="col-sm-2">
					<img src="images/licon2.jpg" style="width: 150px; height: 150px; border-radius: 10px;"><br><br>
					<h6>Hyderabad, India</h6>
					<!-- <p>#1-62-/K/36, 1st Floor, Plot No.36, Survey Number 40 (part) &amp; 41, Kavuri Hills Rd, Hyderabad, Telangana 500033</p> -->
					<!-- <a href="https://maps.google.com/maps?ll=17.445107,78.469469&z=16&t=m&hl=en-US&gl=AE&mapclient=embed&cid=10807821825152221568" target="_blank">View On Google Map</a> -->
                </div>
                <br><br>
                <div class="row">
                    <div class="col-sm-2 text-right"><br><br></div>
                    <div class="col-sm-5 text-right"><br><br>
                        <p style="font-size: 22px; color: white;">Reliable and Advanced Blockchain solutions to help you embrace the new technology and lead the way.</p>
                    </div> 
                    <div class="col-sm-1 text-left"><br><br></div>
                    <!--div class="col-sm-3 text-left"><br><br>
                        <p><a href="tel:+16197149179" style="color: white;"><i class="fa fa-phone"></i> <span style="font-size: 18px;">+16197149179</span></a></p>
                        
                        <p><a href="tel:+971585048744" style="color: white;"><i class="fa fa-phone"></i> <span style="font-size: 18px;">+971585048744</span></a></p>
                        <-- <p>1420 Washington Blvd Ste 301, <br>Detroit, MI 48226<br><br></p> --
                        -- <a href="https://maps.google.com/maps?ll=13.029627,80.208929&z=15&t=m&hl=en&gl=IN&mapclient=embed&cid=622596362192183323" target="_blank">View On Google Map</a> --
                    </div-->
                </div>
				<!-- <div class="col">
					<img src="assets/img/licon3.jpg" style="width: 150px; height: 150px;">
					<h6>Kolkata, India</h6>
					<p>75C, Park Street, 6th Floor, Kolkata, West Bengal – 700016<br><br></p>
					<a href="https://maps.google.com/maps?ll=22.550839,88.35441&z=19&t=h&hl=en&gl=IN&mapclient=embed&q=75C%2C%20Park%20St%20Park%20Street%20area%20Kolkata%2C%20West%20Bengal%20700016" target="_blank">View On Google Map</a>
                </div> -->
			
            </div>
                        </div>
                    </div>    
                </div>
            </div>               
        </div>           
    </div>
    <div id="particles11-js" class="particles"><canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;" width="1440" height="789"></canvas></div>
</section>

<br><br><br>

<?php include('footer.php'); ?>
</body>

</html>
